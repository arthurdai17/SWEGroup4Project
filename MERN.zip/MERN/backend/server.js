const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

require('dotenv').config();

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

const uri = process.env.ATLAS_URI;
mongoose.connect(uri, { useNewUrlParser: true, useCreateIndex: true, useUnifiedTopology: true }
);
const connection = mongoose.connection;
connection.once('open', () => {
  console.log("MongoDB database connection established successfully");
})
mongoose.Promise = global.Promise;

//populate database
var async = require('async');
var Question = require('./models/question.model');
var questions = [];

function questionCreate(questionid, questiontext, choice1, choice2, choice3, choice4, answer, picture, fact, cb) {
  questiondetail = {
    questionid: questionid,
    questiontext: questiontext,
    choice1: choice1,
    choice2: choice2,
    choice3: choice3,
    choice4: choice4,
    answer: answer,
    picture: picture,
    fact: fact
  }

  var question = new Question(questiondetail);
  question.save(function (err) {
    if (err) {
      cb(err, null)
      return
    }
    console.log('New Question : ' + question);
    questions.push(question)
    cb(null, question)
  }  );
}

function createQuestions(cb) {
    async.parallel([
        function(callback) {
          questionCreate(1, "Which of the following is a Cypriot tradition?", "Eating dates when breaking a fast", "Plate Smashing", "Food fights",
          "Eating a roast dinner on Sunday’s", "Plate Smashing", "images/q1.jpeg", "Plate smashing served several purposes in Cypriot tradition. From being a way to deal with anger, mourn a loss or to keep evil spirits at bay, plate smashing was also a way of symbolizing new beginnings and was particularly popular at weddings. It meant that the couple were throwing away their old life and embarking on a new life together.", callback);
        },
        function(callback) {
          questionCreate(2, "When Iraqi men who are friends greet each other, what is the common custom?", "Shake hands", "Hug", "Kiss on the cheek and hold hands when speaking", "Nod", "Kiss on the cheek and hold hands when speaking", "images/q2.jpeg", "Iraqi men usually greet each other with a handshake using the right hand. They tend to shake hands gently, but hold the hand for a long time whilst they exchange greetings. It is also common for Iraqi men to place their hand over their heart when greeting friends to express the sincerity of their words.", callback);
        },
        function(callback) {
          questionCreate(3, "What is the name of the traditional Emirati dance?", "Samba", "Waltz", "Haka", "Al-Ayyalah", "Al-Ayyalah", "images/q3.jpeg", "The Emirati traditional dance is called Al-Ayyalah. It is performed by men and boys who hold thin bamboo canes and move in unison to a steady drummed rhythm. It is typically performed at weddings, national holidays and other celebrations.", callback);
        },
        function(callback) {
          questionCreate(4, "What are the names of the traditional clothes worn by men and women in Saudi Arabia?", "Sari and Kurtha", "Abaya and Thobe", "Lederhosen and Dirndls", "Suit and Dress", "Abaya and Thobe", "images/q4.jpeg", "The traditional clothes worn by men and women in Saudi Arabia are called the Abaya (women) and the Thobe (men). An abaya is usually black in color, and it is a long sleeve, floor length loose gown with a head covering to be worn over a woman’s clothes. A thobe is usually white in color and is a long ankle length garment with long sleeves similar to a robe, kaftan or tunic.", callback);
        },
        function(callback) {
          questionCreate(5, "In Oman, it is customs to serve guests special coffee (Qahwa)...?", "With mint leaves", "With sugar", "With your right hand", "In a clay cup", "With your right hand", "images/q5.jpeg", "In Arab culture the right hand is reserved for eating meals and greeting people. The guest should also only accept the coffee, or any food with their right hand only. This is seen as a sign of respect. Additionally, in most Arab countries, the left hand is seen as being unclean as it is reserved for cleaning yourself.", callback);
        },
        function(callback) {
          questionCreate(6, "What is the name of the Iranian New Year?", "Diwali", "Eid", "Nowruz", "Yom Kippur", "Nowruz", "images/q6.jpeg", "The Iranian (or Persian) new year is called Nowruz! Nowruz marks the first day of spring and is celebrated on the day of the astronomical vernal equinox, which usually occurs on 21 March. Iranians celebrate this day by performing a number of traditions (such as jumping over fires), feasting, visiting family members and friends, and exchanging gifts.", callback);
        },
        function(callback) {
          questionCreate(7, "What is the tradition of Diwāniyyah in Kuwaiti culture?", "A regular gathering of men", "A regular gathering of women", "A special day where mothers give gifts to their daughters", "The tradition of drinking coffee and eating sweet pastries after a meal", "A regular gathering of men", "images/q7.jpeg", "Diwāniyyah is a gathering of men in a separate room, where they talk, play games, and enjoy refreshments. It is at the heart of Kuwaiti tradition and is considered to be a part of a man's social life.", callback);
        },
        function(callback) {
          questionCreate(8, "What are Jordanians known for?", "Their hospitality", "Their technology", "Their eccentric dress sense", "Their sports ability", "Their hospitality", "images/q8.jpeg", "Jordanians pride themselves on their hospitality! Hospitality is deeply engrained in Jordanian culture with origins in Bedouin tradition.During your visit to Jordan its likely that you’ll hear 'ahlan wa sahlan' meaning welcome, on a regular basis! Top tip: 'shukran' means thank you.", callback);
        },
        function(callback) {
          questionCreate(9, "Which of the following is a Lebanese wedding tradition?", "Cutting the wedding cake with a sword", "Rubbing yellow paste on the body of the bride and groom", "Wearing red on the wedding day", "Decorating the venue in white and pink flowers", "Cutting the wedding cake with a sword", "images/q9.jpeg", "It is a Lebanese wedding custom for the bride and groom to cut the wedding cake with a large ceremonial sword! Lebanese wedding cakes are extravagant with some easily reaching 9 layers or more.", callback);
        },
        function(callback) {
          questionCreate(10, "What is the national dish of Egypt?", "Biriyani", "Shawarma", "Fattoush", "Koshari or Kushari", "Koshari or Kushari", "images/q10.jpeg",
          "The National dish of Egypt is Koshari! It originated during the mid-19th century and combines Italian, Indian and Middle Eastern culinary elements. Koshari is a mix of spiced lentils, rice, chickpeas and small pasta which is smothered in a tomato sauce that's been spiked with vinegar and topped with crispy thin fried onion rings!.", callback);
        }

        ],
        // optional callback
        cb);
}

/*async.series([
    createQuestions
],
// Optional callback
function(err, results) {
    if (err) {
        console.log('FINAL ERR: '+err);
    }
    // All done, disconnect from database
    mongoose.connection.close();
});*/

const questionsRouter = require('./routes/questions');
app.use('/questions', questionsRouter);

app.listen(port, () => {
    console.log(`Server is running on port: ${port}`);
});
