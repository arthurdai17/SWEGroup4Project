import React from 'react';
import { BrowserRouter as Router, Route } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

import StartQuiz from "./components/start-quiz.component"
import QuestionItem from "./components/question-item.component";

function App() {
 return (
   <Router>
   <div className="container">
   <Route path="/" exact component={StartQuiz} />
   <Route path="/question" component={QuestionItem} />
   </div>
   </Router>
 );
}

export default App;
