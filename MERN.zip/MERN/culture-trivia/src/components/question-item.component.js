import React, { Component } from 'react';
import axios from 'axios';
import {Link} from "react-router-dom";
import "../index.css";
import image from "./deadsea.jpg";

export default class QuestionItem extends Component {

  constructor(props) {
      super(props);

      this.checkAnswer = this.checkAnswer.bind(this);
      this.nextQuestion = this.nextQuestion.bind(this);

      this.state={
        number: 1,
        questions: [],
        answer: "",
        score: 0,
        disable: false,
        num_elem: 0,
        hidden: "hidden",
        buttonstate: "btn btn-info fw-bold"}
    }

    componentDidMount() {
        axios.get('http://localhost:5000/questions/')
            .then(response => {
            this.setState({ questions: response.data });
        })
            .catch((error) => {
            console.log(error);
        })
    }

    questionItem(){
        const current_question = this.state.questions.map(question => {
            if((question.questionid === this.state.number)){
                return <div key={question.questionid}>
                        <div className="questiontext"><p>{question.questiontext}</p></div>
                        <form>
                            <fieldset disabled={this.state.disable}>
                            <div>
                                <p className="choiceone">
                                    <button className={this.state.buttonstate} onClick={() => this.checkAnswer(question.choice1)}>
                                        {question.choice1}
                                    </button>
                                </p>
                                <p className="choiceone">
                                    <button className={this.state.buttonstate} onClick={() => this.checkAnswer(question.choice2)}>
                                        {question.choice2}
                                    </button>
                                </p>
                                </div>
                                <div>
                                <p className="choiceone">
                                    <button className={this.state.buttonstate} onClick={() => this.checkAnswer(question.choice3)}>
                                        {question.choice3}
                                    </button>
                                </p>
                                <p className="choiceone">
                                    <button className={this.state.buttonstate} onClick={() => this.checkAnswer(question.choice4)}>
                                        {question.choice4}
                                    </button>
                                </p>
                                </div>
                              </fieldset>
                          </form>
                    </div>;
            }
            return null;
        });
        return current_question;
    }

    checkAnswer(choice){
        //console.log("Answer to check : " + choice);
        this.state.questions.map(question => {
            if((question.answer === choice) && (question.questionid === this.state.number)){
              this.setState({answer: <div>
                    <div className="rightanswer">Good answer!</div>
                    <div className="factimage">
                    <img src={question.picture} alt="" width="200" height="200"/>
                    </div>
                    <div className="fact">FACT: {question.fact}</div>
                    </div> });
              this.setState({score: this.state.score+1});
              this.setState({buttonstate: "btn btn-success fw-bold"});
            }
            else if (question.questionid === this.state.number){
                this.setState({answer: <div>
                    <p className="wronganswer">WRONG ANSWER!</p>
                    <div className="factimage">
                    <img src={question.picture} alt="" width="200" height="200"/>
                    </div>
                    <div className="correctanswer">The correct answer was: {question.answer}</div>
                    <div className="fact">FACT: {question.fact}</div>
                    </div>});
                    this.setState({buttonstate: "btn btn-danger fw-bold"});
            }
        });
        this.setState({disable: true});
        this.setState({hidden: ""})
    }

    nextQuestion(){
        this.setState({ number: this.state.number + 1 });
        this.setState({answer: ""});
        this.setState({disable: false});
        this.setState({num_elem: this.state.questions.length});
        this.setState({hidden: "hidden"});
        this.setState({buttonstate: "btn btn-info fw-bold"});
        if(this.state.num_elem === this.state.number){
          this.setState({answer: <div className="welldone">
            Well done you've finished the quiz!
            <div className="afterwelldone">
            <Link to="/">
            <button className="btn btn-primary fw-bolder">Click here to go back to start!</button>
            </Link>
            </div>
            </div>});

        }
    }

  render() {
    return (
      <div className="quizbackground" style={{backgroundImage: `url(${image}`}}>
        <div className="textbox">
        {this.questionItem()}
        {this.state.answer}
        <div className="score"><p>Score: {this.state.score} / 10</p></div>
        <p className="nextbuttondiv">
        <button className="nextbutton" onClick={this.nextQuestion} hidden={this.state.hidden}>Next question</button>
        </p>
        </div>
      </div>
    )
  }
}
