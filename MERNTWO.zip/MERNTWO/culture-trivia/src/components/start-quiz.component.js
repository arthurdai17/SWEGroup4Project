import React, { Component } from 'react';
import {Link} from "react-router-dom";
import image from "./background.jpg";
import "../index.css";

export default class StartQuiz extends Component {
  render() {
    return (
      <div className="logo" style={{backgroundImage: `url(${image}`}}>
     <div>
        <h1 className="header fw-bolder text-center">Welcome to Culture Trivia!</h1>
        <div>
        <h2 className="explanation text-center"> How well do you know Middle Eastern culture? </h2>
        </div>
        <div>
        <h3 className="explanationtwo text-center"> Take the quiz below and see if you can get 10/10! </h3>
        </div>
        <div className="startbutton text-center">
        <Link to="/question">
        <button className="startbuttonformat">Start Quiz!</button>
        </Link>
        </div>
      </div>
      </div>
    )
  }
}
